//Settings.initHtml();
//console.log(Settings);
//browser.runtime.openOptionsPage();